// Copyright 2013 Steve Gribble -- gribble (at) gmail (dot) com

#include <algorithm>
#include <cinttypes>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <map>
#include <string>
#include <utility>

#include "./AI.h"
#include "./HexBoard.h"

// This is an auxiliary program that, given the size of a board,
// calculating the best possible AI response to particular early board
// configurations. In particular, the program calculates the best
// possible opening move for the AI, the best possible response move
// for the AI given all possible player opening moves, and the best
// possible 2nd move of the AI, after all possible AI opening moves
// and player second moves.
//
// After calculating these moves, the program emits to standard output
// a list of (board position hash, (next_move_x, next_move_y))
// entries. The "gameplay.cc" program can optionally read in a file
// containing this output to use the precalculated moves.
int main(int argc, char **argv) {
  // Get the board dimensions from argv.
  uint64_t width, height;
  if (argc != 3) {
    std::cerr << "Usage: ./gameplay boardwidth boardheight" << std::endl;
    return EXIT_FAILURE;
  }
  width = std::stoull(argv[1]);
  height = std::stoull(argv[2]);
  if ((width > 65535) || (height > 65535) ||
      (width == 0) || (height == 0)) {
    std::cerr << "width/height must be > 0 and < 65536." << std::endl;
    return EXIT_FAILURE;
  }

  // Create the AI and the map of cached moves.
  hw5::AI ai;
  std::map<uint64_t, std::pair<uint16_t, uint16_t>> movemap;

  // 0-move boards, i.e., figure out the best opening move for the AI,
  // assuming it moves first.
  ai.set_num_trials(250);
  {
    hw5::HexBoard hb(width, height);
    hw5::HexBoard::occupancy nextmover = hw5::HexBoard::RED;
    movemap[hb.Hash()] = ai.FindNextMove(hb, nextmover, 2);
  }

  // 1-move boards, i.e., for each possible opening move from a
  // player, calculate the best possible response move from the AI.
  ai.set_num_trials(1000);
  for (uint16_t x = 0; x < width; ++x) {
    for (uint16_t y = 0; y < height; ++y) {
      {
        hw5::HexBoard hb(width, height);
        hw5::HexBoard::occupancy nextmover = hw5::HexBoard::RED;
        hb.SetOccupancy(x, y, nextmover);
        nextmover = hw5::HexBoard::BLUE;
        movemap[hb.Hash()] = ai.FindNextMove(hb, nextmover, 1);
      }
      {
        hw5::HexBoard hb(width, height);
        hw5::HexBoard::occupancy nextmover = hw5::HexBoard::BLUE;
        hb.SetOccupancy(x, y, nextmover);
        nextmover = hw5::HexBoard::RED;
        movemap[hb.Hash()] = ai.FindNextMove(hb, nextmover, 1);
      }
    }
  }

  // 2-move boards.
  ai.set_num_trials(250);
  for (uint16_t x = 0; x < width; ++x) {
    for (uint16_t y = 0; y < height; ++y) {
      for (uint16_t x2 = 0; x2 < width; ++x2) {
        for (uint16_t y2 = 0; y2 < width; ++y2) {
          if ((x == x2) && (y == y2))
            continue;
          {
            hw5::HexBoard hb(width, height);
            hw5::HexBoard::occupancy nextmover = hw5::HexBoard::RED;
            hb.SetOccupancy(x, y, nextmover);
            nextmover = hw5::HexBoard::BLUE;
            hb.SetOccupancy(x2, y2, nextmover);
            nextmover = hw5::HexBoard::RED;
            movemap[hb.Hash()] = ai.FindNextMove(hb, nextmover, 1);
          }
          {
            hw5::HexBoard hb(width, height);
            hw5::HexBoard::occupancy nextmover = hw5::HexBoard::BLUE;
            hb.SetOccupancy(x, y, nextmover);
            nextmover = hw5::HexBoard::RED;
            hb.SetOccupancy(x2, y2, nextmover);
            nextmover = hw5::HexBoard::BLUE;
            movemap[hb.Hash()] = ai.FindNextMove(hb, nextmover, 1);
          }
        }
      }
    }
  }

  // Write the results out.
  for (auto moves : movemap) {
    std::cout << moves.first << " "
              << moves.second.first << " " << moves.second.second
              << std::endl;
  }

  return EXIT_SUCCESS;
}
