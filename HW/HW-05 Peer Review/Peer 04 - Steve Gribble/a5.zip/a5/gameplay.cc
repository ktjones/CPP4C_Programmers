// Copyright 2013 Steve Gribble -- gribble (at) gmail (dot) com

#include <algorithm>
#include <cstdlib>
#include <iostream>
#include <string>
#include <utility>
#include <inttypes.h>

#include "./AI.h"
#include "./HexBoard.h"

// Parses and returns either "red" or "blue" from stdin.
std::string GetPlayer(const std::string &message);

// Prints the game instructions, then asks the user whether red or
// blue should move first, and whether the user wants to be red or
// blue. Returns a std::pair<std::string, std::string> with the
// answers ("red" or "blue" for each).
std::pair<std::string, std::string> PrintIntro(const hw5::HexBoard &board);

// Gets the next move from the user. Returns the move coordinates
// through the variables "x" and "y".  Returns true if it was able to
// get a uint16_t move, false otherwise.
bool GetNextMove(uint16_t width, uint16_t height, uint16_t *x, uint16_t *y);

// This is the main program for interacting with a hex AI. It makes
// use of the AI and HexBoard classes defined in AI.[h|cc] and
// HexBoard.[h|cc].
//
// The program has two mandatory command line arguments (width and
// height), as well as an optional third command line argument (the
// name of a board cache file). The board cache file should contain a
// list of precomputed responses to opening moves, as calculated and
// emitted by the "boardsearch.cc" program. The cache file speeds up
// the opening gameplay.
int main(int argc, char **argv) {
  // Get the board dimensions from argv.
  uint64_t width, height;
  if (argc < 3) {
    std::cerr << "Usage: ./gameplay boardwidth boardheight [cachefile]" << std::endl;
    return EXIT_FAILURE;
  }
  width = std::stoull(argv[1]);
  height = std::stoull(argv[2]);
  if ((width > UINT16_MAX) || (height > UINT16_MAX) ||
      (width == 0) || (height == 0)) {
    std::cerr << "width/height must be > 0 and < 65536." << std::endl;
    return EXIT_FAILURE;
  }

  // Prep the hexboard, print out the game intro.
  hw5::HexBoard hb(width, height);
  hw5::AI ai;
  ai.set_num_trials(1000);
  if (argc == 4)
    ai.ReadCacheFile(argv[3]);
  std::pair<std::string, std::string> answers = PrintIntro(hb);
  hw5::HexBoard::occupancy who_moves_next =
    answers.first == "blue" ? hw5::HexBoard::BLUE : hw5::HexBoard::RED;
  hw5::HexBoard::occupancy player_color =
    answers.second == "blue" ? hw5::HexBoard::BLUE : hw5::HexBoard::RED;

  // Enter the main game loop.
  while (true) {
    // Get the next move, either from the player or the AI.
    if (who_moves_next == player_color) {
      std::cout << "Enter your next move, "
                << (player_color == hw5::HexBoard::BLUE ? "blue" : "red")
                << " (e.g., \"4 7\"): " << std::endl;

      uint16_t x, y;
      if (!GetNextMove(width, height, &x, &y)) {
        continue;
      }

      if (!hb.SetOccupancy(x, y, player_color)) {
        std::cout << "Sorry, that cell is occupied already." << std::endl;
        continue;
      }
    } else {
      std::cout << "Calculating next move for "
                << (who_moves_next == hw5::HexBoard::BLUE ? "blue" : "red")
                << "..." << std::endl;
      std::pair<uint16_t, uint16_t> aimove =
        ai.FindNextMove(hb, who_moves_next, 1);
      std::cout << "  done. Move is (" << aimove.first
                << ", " << aimove.second << ")." << std::endl;
      hb.SetOccupancy(aimove.first, aimove.second, who_moves_next);
    }

    // Print out the post-move board configuration.
    std::cout << std::endl << hb.ToString() << std::endl;

    // Decide whether the game should terminate because somebody won.
    if (hb.HasBlueWon()) {
      std::cout << "Blue has won!" << std::endl;
      exit(EXIT_SUCCESS);
    }
    if (hb.HasRedWon()) {
      std::cout << "Red has won!" << std::endl;
      exit(EXIT_SUCCESS);
    }

    // Loop back around, switching who moves next.
    who_moves_next = (who_moves_next == hw5::HexBoard::BLUE ?
                      hw5::HexBoard::RED : hw5::HexBoard::BLUE);
  }
  return EXIT_SUCCESS;
}

std::pair<std::string, std::string> PrintIntro(const hw5::HexBoard &board) {
  // Print out the game header.
  std::cout << std::endl;
  std::cout << "Welcome to hexboard! Written by gribble [at] gmail.com."
            << std::endl << std::endl;
  std::cout << board.ToString() << std::endl;
  std::cout << "Blue (B) connects West<-->East, "
            << "Red (R) connects North<-->South."
            << std::endl;
  std::cout << "The top-left of the board is x=0, y=0 and the bottom-right"
            << std::endl << "of the board is x=" << board.get_width() - 1
            << ", y=" << board.get_height() - 1 << "." << std::endl;

  // Ask who should move first.
  std::cout << std::endl;
  return std::pair<std::string, std::string>(
    GetPlayer("Who would you like to move first: Blue (B) or Red (R)?"),
    GetPlayer("Who would you like be: Blue (B) or Red (R)?"));
}

bool GetNextMove(uint16_t width, uint16_t height, uint16_t *x, uint16_t *y) {
  uint16_t inx, iny;
  std::cin >> inx;
  std::cin >> iny;
  if (std::cin.good()) {
    if ((inx >= width) || (iny >= height)) {
      std::cerr << "Sorry, that move exceeds the board dimensions."
                << std::endl;
      return false;
    }
    *x = inx;
    *y = iny;
    return true;
  }
  if (std::cin.eof()) {
    exit(EXIT_FAILURE);
  }
  std::cin.clear();
  std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
  std::cout << "Sorry, please input two integers for x and y."
            << std::endl;
  return false;
}

std::string GetPlayer(const std::string &message) {
  std::string movefirst;
  while ((movefirst != "r") && (movefirst != "b") &&
         (movefirst != "red") && (movefirst != "blue")) {
    std::cout << message << std::endl;
    std::cin >> movefirst;
    if (!std::cin.good()) {
      std::cerr << "Reading from standard input failed." << std::endl;
      exit(EXIT_FAILURE);
    }
    std::transform(movefirst.begin(), movefirst.end(), movefirst.begin(),
                   ::tolower);
  }

  if ((movefirst == "r") || (movefirst == "red")) {
    return "red";
  }
  return "blue";
}
