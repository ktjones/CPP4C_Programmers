// Copyright 2013 Steve Gribble -- gribble (at) gmail (dot) com

#ifndef _HW5_AI_H_
#define _HW5_AI_H_

#include <map>
#include <string>
#include <utility>
#include <inttypes.h>

#include "./HexBoard.h"

namespace hw5 {

// The AI class uses MonteCarlo simulation and minmax to calculate
// a next move for a particular player of a HexBoard game, given
// the current game state as input.
class AI {
 public:
  AI() : num_trials_(1000), re_(rd_()) { }
  virtual ~AI() { }

  // Reads a cache file of opening move positions, which was
  // previously computed with the boardsearch.cc program. Fails
  // silently if the cache file cannot be opened or parsed.
  void ReadCacheFile(std::string filename);

  // This method returns a std::pair containing the (x, y) move that
  // the AI calculates is the best next move for the player "player."
  // If no move is possible (because the board is full), this method
  // will exit(EXIT_FAILURE). Note that if this happens, there is a
  // bug somewhere in the gameplay, since Hex is guaranteed to never
  // end in a tie: one of the players must win.
  //
  // "num_plys" is the number of plys, i.e., moves ahead, to look
  // using minimax with alpha-beta pruning before resorting to Monte
  // Carlo static evaluation of children.
  //
  // If the AI finds a move in the previously read move cache, it
  // will use that instead.
  std::pair<uint16_t, uint16_t>
    FindNextMove(const HexBoard &board, HexBoard::occupancy player,
                 uint32_t num_plys);

  // Set the number Monte Carlo trials to statically evaluate a
  // board position.
  void set_num_trials(uint32_t num_trials) { num_trials_ = num_trials; }

 private:
  // The number of Monte Carlo trials used to statically evaluate a
  // board position.
  uint32_t num_trials_;

  // The number of threads to spawn during the Monte Carlo trials.
  static const uint32_t kNumThreads_ = 24;

  // The random number generators we use.
  std::random_device rd_;
  std::default_random_engine re_;

  // A cache of precomputed moves, given a board position hash.
  std::map<uint64_t, std::pair<uint16_t, uint16_t>> movecache_;


  // This function uses recursive minimax with alpha-beta pruning
  // to evaluate "player"'s winning probability of a given
  // position. "board" is the board state to evaluate, "player" is the
  // player that we are trying to help win, and "nextmover" is the
  // player that will move next.
  //
  // num_plys_left is the number of board moves to evaluate using
  // minimax. If this number is zero, we instead evaluate using
  // MonteCarlo. alpha and beta are the current alpha and beta
  // values of the alpha-beta pruning.
  double MinimaxAlphaBeta(HexBoard board, HexBoard::occupancy player,
                          HexBoard::occupancy nextmover,
                          uint32_t num_plys_left, double alpha,
                          double beta);

  // This function ranks a board position using Monte Carlo,
  // returning a double in the range [0.0, 1.0]. Higher values
  // indicate better positions for "player."
  double CalculateProbability(const HexBoard &board,
                              HexBoard::occupancy player,
                              HexBoard::occupancy nextmover);

  // This is a helper function for CalculateProbability; this
  // method gets invoked in a separate thread to enable thread-level
  // parallelism in the CalculateProability loop. The function
  // runs "num_trials" monte carlo trials, and returns the number of
  // wins.
  uint32_t DoMonteCarlo(const HexBoard &board,
                        HexBoard::occupancy player,
                        HexBoard::occupancy nextmover,
                        uint32_t num_trials);
};

} // end namespace hw5

#endif // _HW5_AI_H_
