// Copyright 2013 Steve Gribble -- gribble (at) gmail (dot) com

#include <algorithm>
#include <cinttypes>
#include <climits>
#include <cstdint>
#include <cstdlib>
#include <future>
#include <iostream>
#include <limits>
#include <map>
#include <memory>
#include <random>
#include <set>
#include <thread>

#include "./AI.h"

namespace hw5 {

// See AI.h for detailed comments describing the public methods of the
// AI class.

std::pair<uint16_t, uint16_t>
AI::FindNextMove(const HexBoard &board, HexBoard::occupancy player,
                 uint32_t num_plys) {
  // Sanity check the arguments.
  if (player == HexBoard::EMPTY) {
    std::cerr << "AI::FindNextMove() called, but player is EMPTY."
              << std::endl;
    exit(EXIT_FAILURE);
  }

  // Check the move cache.
  uint64_t boardhash = board.Hash();
  auto cache_it = movecache_.find(boardhash);
  if (cache_it != movecache_.end()) {
    std::cout << "found cache entry" << std::endl;
    return movecache_[boardhash];
  }

  // Figure out all of the empty slots on the board and create a map
  // of move --> win_probability.
  std::map<std::pair<uint16_t, uint16_t>, double> moves;
  for (uint16_t x = 0; x < board.get_width(); ++x) {
    for (uint16_t y = 0; y < board.get_height(); ++y) {
      if (board.GetOccupancy(x, y) == HexBoard::EMPTY) {
        moves[std::pair<uint16_t, uint16_t>(x, y)] = 0.0;
      }
    }
  }

  // If there are no moves left, signal an error and exit().
  if (moves.size() == 0U) {
    std::cerr << "AI::FindNextMove() called, but no move remains."
              << std::endl;
    exit(EXIT_FAILURE);
  }

  // Iterate through the moves and update the probabilities.
  double beta = std::numeric_limits<double>::infinity();
  double alpha = -beta;
  for (auto &keyval : moves) {
    HexBoard nextboard(board);
    nextboard.SetOccupancy(keyval.first.first, keyval.first.second, player);
    moves[keyval.first] = MinimaxAlphaBeta(nextboard, player,
                                           player == HexBoard::BLUE ?
                                           HexBoard::RED : HexBoard::BLUE,
                                           num_plys, alpha, beta);
    if (moves[keyval.first] > alpha)
      alpha = moves[keyval.first];
  }

  // Find the best move and return it.
  std::pair<uint16_t, uint16_t> bestmove = moves.begin()->first;
  double bestmoveprob = moves.begin()->second;
  for (auto &keyval : moves) {
    if (keyval.second > bestmoveprob) {
      bestmove = keyval.first;
      bestmoveprob = keyval.second;
    }
  }
  return bestmove;
}

void AI::ReadCacheFile(std::string filename) {
  // Try to open up filename.
  std::ifstream ifile(filename);
  if (!ifile.is_open()) {
    std::cerr << "Warning: HexBoard::ReadCacheFile(\"" << filename
	      << "\") failed to open the file." << std::endl;
    return;
  }

  // Loop through, reading entries.
  while (ifile.good()) {
    uint64_t boardhash;
    uint16_t x, y;

    ifile >> boardhash;
    ifile >> x;
    ifile >> y;
    if (!ifile.good())
      break;

    movecache_[boardhash] = std::make_pair(x, y);
  }

  ifile.close();
}

double AI::MinimaxAlphaBeta(HexBoard board, HexBoard::occupancy player,
                            HexBoard::occupancy nextmover,
                            uint32_t num_plys_left, double alpha,
                            double beta) {
  // Short circuit winning board positions.
  if (board.HasBlueWon()) {
    if (player == HexBoard::BLUE)
      return 1.0;
    return 0.0;
  }
  if (board.HasRedWon()) {
    if (player == HexBoard::RED)
      return 1.0;
    return 0.0;
  }

  // If we've run out of plys, use Monte Carlo.
  if (num_plys_left == 0) {
    return CalculateProbability(board, player, nextmover);
  }

  // Build up the set of next moves.
  std::set<std::pair<uint16_t, uint16_t> > moves;
  for (uint16_t x = 0; x < board.get_width(); ++x) {
    for (uint16_t y = 0; y < board.get_height(); ++y) {
      if (board.GetOccupancy(x, y) == HexBoard::EMPTY) {
        moves.insert(std::pair<uint16_t, uint16_t>(x, y));
      }
    }
  }
  // Sanity check.
  if (moves.size() == 0) {
    std::cerr << "In AI::MinimaxAlphaBeta(), but ran out of moves."
              << std::endl;
    exit(EXIT_FAILURE);
  }

  // Recurse through moves.
  for (const auto &move : moves) {
    HexBoard newboard(board);
    newboard.SetOccupancy(move.first, move.second, nextmover);
    double result = MinimaxAlphaBeta(newboard, player,
                                     nextmover == HexBoard::BLUE ?
                                     HexBoard::RED : HexBoard::BLUE,
                                     num_plys_left-1, alpha, beta);
    // Do pruning.
    if (player == nextmover) {
      if (result > alpha)
        alpha = result;
      if (alpha >= beta)
        return alpha;
    } else {
      if (result < beta)
        beta = result;
      if (beta <= alpha)
        return beta;
    }
  }

  // Out of children, so return alpha/beta, as appropriate.
  if (player == nextmover)
    return alpha;
  return beta;
}

double AI::CalculateProbability(const HexBoard &board,
                                HexBoard::occupancy player,
                                HexBoard::occupancy nextmover) {
  // Do the MonteCarlo simulations to see what fraction of the
  // time "player" wins from this position.
  uint32_t num_wins = 0;

  /*
  // Loop, spawning kNumThreads_ at a time, until we're done.
  uint32_t trials_per_thread = num_trials_ / kNumThreads_ + 1;
  std::unique_ptr<std::future<uint32_t>[]> futures(
    new std::future<uint32_t>[kNumThreads_]);
  for (uint32_t i = 0; i < kNumThreads_; ++i) {
    futures[i] = std::async(std::launch::async,
                            &AI::DoMonteCarlo, this,
                            board, player, nextmover, trials_per_thread);
  }
  for (uint32_t i = 0; i < kNumThreads_; ++i) {
    num_wins += futures[i].get();
  }
  */
  num_wins += DoMonteCarlo(board, player, nextmover, num_trials_);

  // Return the fraction of trials that were winners for 'player'.
  double winprob = static_cast<double>(num_wins) /
    static_cast<double>(num_trials_);

  return winprob;
}

uint32_t AI::DoMonteCarlo(const HexBoard &board,
                          HexBoard::occupancy player,
                          HexBoard::occupancy nextmover,
                          uint32_t num_trials) {
  uint32_t num_wins = 0;
  for (uint32_t i = 0; i < num_trials; ++i) {
    HexBoard newboard(board);

    // Build a set of available moves.
    std::set<std::pair<uint16_t, uint16_t>> moves;
    for (uint16_t x = 0; x < newboard.get_width(); ++x) {
      for (uint16_t y = 0; y < newboard.get_height(); ++y) {
        if (newboard.GetOccupancy(x, y) == HexBoard::EMPTY) {
          moves.insert(std::pair<uint16_t, uint16_t>(x, y));
        }
      }
    }

    // We're not yet in a winning position. Keep randomly selecting
    // moves until there are none left or until somebody wins.
    HexBoard::occupancy nextplayer = nextmover;
    while (moves.size() > 0) {
      // Make the next move.
      std::uniform_int_distribution<uint32_t> choose(0, moves.size() - 1);
      auto moveit = moves.begin();
      std::advance(moveit, choose(re_));
      auto nextmove = *moveit;
      moves.erase(moveit);
      newboard.SetOccupancy(nextmove.first, nextmove.second, nextplayer);

      // See if we're in a winning position.
      if (newboard.HasBlueWon()) {
        if (player == HexBoard::BLUE)
          ++num_wins;
        break;
      }
      if (newboard.HasRedWon()) {
        if (player == HexBoard::RED)
          ++num_wins;
        break;
      }

      // Switch players.
      nextplayer = (nextplayer == HexBoard::BLUE ?
                    HexBoard::RED : HexBoard::BLUE);
    }
  }
  return num_wins;
}

} // end namespace hw5
