// Copyright 2013 Steve Gribble -- gribble (at) gmail (dot) com

#include <cstdlib>
#include <fstream>
#include <iostream>
#include <map>

#include "./Graph.h"
#include "./HexBoard.h"
#include "./UnionFindForest.h"

namespace hw5 {

// See HexBoard.h for detailed comments describing the public methods
// of the HexBoard class.

HexBoard::HexBoard(uint16_t width, uint16_t height)
  : width_(width), height_(height), blueforest_(width * height + 4),
    redforest_(width * height + 4) {
  // Sanity check the arguments.
  if ((width_ == 0) || (height_ == 0)) {
    std::cerr << "HexBoard() constructor called with zero width or height."
              << std::endl;
    exit(EXIT_FAILURE);
  }

  // Add the graph nodes.
  for (uint16_t row = 0; row < height_; ++row) {
    for (uint16_t col = 0; col < width_; ++col) {
      if (graph_.AddNode(EMPTY) != ((row * width_) + col)) {
        std::cerr << "graph_.AddNode() returned unexpected Node identifier."
                  << std::endl;
        exit(EXIT_FAILURE);
      }
    }
  }

  // Add the percolation check nodes/edges to make union find work.
  // We will maintain two union find forests: one for blue nodes and
  // one for red nodes. We then add two virtual nodes for blue (one to
  // the left of the board that connects to all left edge nodes and
  // one to the right of the board that connects to all right edge
  // nodes), and we do something similar for red. Then, anytime we
  // connect two blue nodes, we union them in the blue union find
  // forest. Once the two blue virtual nodes are in the same set,
  // we know blue has won. Ibid for red.
  blueleft_ = graph_.AddNode(BLUE);
  blueright_ = graph_.AddNode(BLUE);
  for (uint16_t row = 0; row < height_; ++row) {
    graph_.AddEdge(blueleft_, (0) + (row * width_), 1.0);
    blueforest_.Union(blueleft_, (0) + (row * width_));
    graph_.AddEdge((width_ - 1) + (row * width_), blueright_, 1.0);
    blueforest_.Union((width_ - 1) + (row * width_), blueright_);
  }
  redtop_ = graph_.AddNode(RED);
  redbottom_ = graph_.AddNode(RED);
  for (uint16_t col = 0; col < width_; ++col) {
    graph_.AddEdge(redtop_, col + (0 * width_), 1.0);
    redforest_.Union(redtop_, col + (0 * width_));
    graph_.AddEdge(col + ((height_ - 1) * width_), redbottom_, 1.0);
    redforest_.Union(col + ((height_ - 1) * width_), redbottom_);
  }
}

HexBoard::occupancy HexBoard::GetOccupancy(uint16_t x, uint16_t y) const {
  // Sanity check the arguments.
  if ((x >= width_) || (y >= height_)) {
    std::cerr << "GetOccupancy() called with position beyond board edges."
              << std::endl;
    exit(EXIT_FAILURE);
  }
  return graph_.get_node_value(x + (y * width_));
}

bool HexBoard::SetOccupancy(uint16_t x, uint16_t y,
                            HexBoard::occupancy color) {
  // Sanity check the arguments.
  if ((x >= width_) || (y >= height_)) {
    std::cerr << "SetOccupancy() called with position beyond board edges."
              << std::endl;
    exit(EXIT_FAILURE);
  }
  if (color == EMPTY) {
    std::cerr << "SetOccupancy() called with EMPTY as color."
              << std::endl;
    exit(EXIT_FAILURE);
  }

  // See if the square is already taken.
  if (GetOccupancy(x, y) != EMPTY) {
    return false;
  }

  // Set the graph to the new occupancy.
  graph_.set_node_value(x + (y * width_), color);

  // Set the connections to neighboring cells of the same occupancy.
  // First to left edge.
  if (x != 0) {
    if (GetOccupancy(x - 1, y) == color) {
      uint32_t from = (x - 1) + (y * width_);
      uint32_t to = x + (y * width_);
      graph_.AddEdge(from, to, 1.0);
      if (color == BLUE)
        blueforest_.Union(from, to);
      else
        redforest_.Union(from, to);
    }
  }

  // To right edge.
  if (x != width_ - 1) {
    if (GetOccupancy(x + 1, y) == color) {
      uint32_t from = x + (y * width_);
      uint32_t to = (x + 1) + (y * width_);
      graph_.AddEdge(from, to, 1.0);
      if (color == BLUE)
        blueforest_.Union(from, to);
      else
        redforest_.Union(from, to);
    }
  }

  // To upper-left.
  if (y != 0) {
    if (GetOccupancy(x, y - 1) == color) {
      uint32_t from = x + ((y - 1) * width_);
      uint32_t to = x + (y * width_);
      graph_.AddEdge(from, to, 1.0);
      if (color == BLUE)
        blueforest_.Union(from, to);
      else
        redforest_.Union(from, to);
    }
  }

  // To upper-right.
  if ((x != (width_ - 1)) && (y != 0)) {
    if (GetOccupancy(x + 1, y - 1) == color) {
      uint32_t from = (x + 1) + ((y - 1) * width_);
      uint32_t to = x + (y * width_);
      graph_.AddEdge(from, to, 1.0);
      if (color == BLUE)
        blueforest_.Union(from, to);
      else
        redforest_.Union(from, to);
    }
  }

  // To bottom-left.
  if ((x != 0) && (y != height_ - 1)) {
    if (GetOccupancy(x - 1, y + 1) == color) {
      uint32_t from = x + (y * width_);
      uint32_t to = (x - 1) + ((y + 1) * width_);
      graph_.AddEdge(from, to, 1.0);
      if (color == BLUE)
        blueforest_.Union(from, to);
      else
        redforest_.Union(from, to);
    }
  }

  // To bottom-right.
  if (y != height_ - 1) {
    if (GetOccupancy(x, y + 1) == color) {
      uint32_t from = x + (y * width_);
      uint32_t to = x + ((y + 1) * width_);
      graph_.AddEdge(from, to, 1.0);
      if (color == BLUE)
        blueforest_.Union(from, to);
      else
        redforest_.Union(from, to);
    }
  }

  return true;
}

const Graph<HexBoard::occupancy, double>& HexBoard::GetGraph() const {
  return graph_;
}

bool HexBoard::HasBlueWon() {
  return (blueforest_.Find(blueleft_) == blueforest_.Find(blueright_));
}

bool HexBoard::HasRedWon() {
  return (redforest_.Find(redtop_) == redforest_.Find(redbottom_));
}

std::string HexBoard::ToString() const {
  static std::string kBorder = "◼", kEmpty = "•", kBlue = "B", kRed = "R";
  static std::map<occupancy, std::string> char_map = {{EMPTY, kEmpty},
                                                      {BLUE, kBlue},
                                                      {RED, kRed}};
  static std::map<bool, std::string> horiz_map = {{true, "-"}, {false, " "}};
  static std::map<bool, std::string> lrd_map = {{true, "\\"}, {false, " "}};
  static std::map<bool, std::string> rld_map = {{true, "/"}, {false, " "}};
  std::string retstr;

  // Do the top border.
  for (uint32_t offset = 0U; offset < (width_ - 1U) * 4U + 5U; ++offset) {
    retstr += kBorder;
  }
  retstr += '\n';

  // Do the rows.
  for (uint16_t row = 0; row < height_; ++row) {
    // Do a horizontal row. First, place the border.
    retstr += " ";
    for (uint16_t i = 0; i < row; ++i) retstr += "  ";
    retstr += kBorder + " ";
    // Next, place the pieces and horizontal edges.
    for (uint16_t col = 0; col < width_; ++col) {
      retstr += char_map[GetOccupancy(col, row)];
      if (col != width_ - 1) {
        retstr += " ";
        retstr += horiz_map[graph_.AreNodesAdjacent(row * width_ + col,
                                                    row * width_ + col + 1)];
        retstr += " ";
      }
    }
    // Finish up with the border.
    retstr += " " + kBorder + "\n";

    if (row != height_ - 1) {
      // Do a diagonal edge row. First, place the border.
      retstr += "  ";
      for (uint16_t i = 0; i < row; ++i) retstr += "  ";
      retstr += kBorder + " ";
      for (uint16_t col = 0; col < width_; ++col) {
        // Next, place the diagonal edges.
        retstr += lrd_map[graph_.AreNodesAdjacent(row * width_ + col,
                                                  (row + 1) * width_ + col)];
        if (col != width_ - 1) {
          retstr += " ";
          retstr += rld_map[graph_.AreNodesAdjacent(row * width_ + col + 1,
                                                    (row + 1) * width_ + col)];
          retstr += " ";
        }
      }
      // Finish up with the border.
      retstr += " " + kBorder + "\n";
    }
  }

  // Do the final border.
  for (uint32_t offset = 0; offset < height_ * 2; offset++) {
    retstr += " ";
  }
  for (uint32_t offset = 0U; offset < (width_ - 1U) * 4U + 5U; ++offset) {
    retstr += kBorder;
  }
  retstr += '\n';

  return retstr;
}

uint64_t HexBoard::Hash() const {
  // This is an implementation of the "djb2" hash function, invented
  // by Daniel J. Bernstein and posted by him on comp.lang.c.
  std::string boardstr = ToString();
  uint64_t hash = 5381;
  for (uint32_t i = 0; i < boardstr.size(); ++i) {
    hash = ((hash << 5) + hash) + boardstr[i];
  }
  return hash;
}

} // end namespace hw5
